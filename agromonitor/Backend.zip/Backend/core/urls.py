from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('Cadastro.urls')),
    path('api/sensores/', include('sensores.urls')),
    path('dashboard/', include('Monitor.urls')),
]